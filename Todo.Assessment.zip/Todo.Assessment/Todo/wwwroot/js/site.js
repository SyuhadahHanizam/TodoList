﻿function deleteTodo(i) 
{
    $.ajax({
        url: 'Home/Delete',
        type: 'POST',
        data: {
            id: i
        },
        success: function() {
            window.location.reload();
        }
    });
}

function populateForm(i) {

    $.ajax({
        url: 'Home/PopulateForm',
        type: 'GET',
        data: {
            id: i
        },
        dataType: 'json',
        success: function (response) {
            $("#Todo_Task").val(response.task);
            $("#Todo_Id").val(response.id);
            $("#form-button").val("Update Task");
            $("#form-action").attr("action", "/Home/Update");
        }
    });
}